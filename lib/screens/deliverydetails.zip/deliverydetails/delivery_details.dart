import 'package:craft_corner/screens/deliverydetails/single_detail.dart';
import 'package:craft_corner/screens/ordersummary/order_summary.dart';
import 'package:flutter/material.dart';

class DeliveryDetails extends StatefulWidget {

  const DeliveryDetails({super.key});

  @override
  State<DeliveryDetails> createState() => _DeliveryDetailsState();
}

class _DeliveryDetailsState extends State<DeliveryDetails> {
  List<Widget> address=[
    const SingleDeliveryItem(
        title: "Navyasri",
        addressType: "Home",
        address: '14-149, Rangaswami bazar, Jaggayyapet, Krishna, 521175',
        number: "+91 8074722516"
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Delivery Details"),
        leading :BackButton(),
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        child: Icon(Icons.add),
        onPressed: () {},
      ),
      bottomNavigationBar: Container(
        height: 48,
        margin: EdgeInsets.symmetric(vertical: 10,horizontal: 20),
        child: MaterialButton(
          child: Text(" proceed to payment",style: TextStyle(color: Colors.white),),
          onPressed: (){
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => OrderDetails())
            );
          },
          color: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
        ),
      ),
      body: ListView(
        children: [
          ListTile(
            title: Text("Deliver To"),
            leading: Image.asset("assets/image/profile.jpg",height: 30,),
          ),
          Divider(height: 1,),
          Column(
            children: [
              SingleDeliveryItem(
                  title: "Prasad",
                  addressType: "Home",
                  address: 'VRSEC,Vijayawada',
                  number: "+91 8074722516"
              ),
            ],
          )
        ],
      ),
    );
  }
}